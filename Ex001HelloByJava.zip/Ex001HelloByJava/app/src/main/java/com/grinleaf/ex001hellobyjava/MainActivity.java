package com.grinleaf.ex001hellobyjava;

import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //화면에 보이는 뷰들의 참조변수는 가급적 멤버변수로 만들 것
    TextView tv;
    Button btn;
    LinearLayout layout;

    //액티비티가 생성되면 자동으로 실행되는 콜백메소드
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);

        //Java 언어 만으로 화면 꾸미기

        //액티비티에 놓여질 수 있는 것은 View 클래스를 상속받은 클래스들만 가능!
        //글씨를 보여주는 TestView 객체 생성 및 설정
        tv= new TextView(this);
        tv.setText("Hello world!");

        //액티비티에 View를 붙이기
       // this.setContentView(tv);

        //버튼 역할을 하는 객체를 생성 및 설정
        btn= new Button(this);
        btn.setText("버튼");

        //액티비티에 View 붙이기(this.은 동일 패키지내 생략 가능)
       // setContentView(btn);

        //액티비티는 한 번에 1개의 View만 놓여질 수 있음(자바의 add는 버튼이 기존 버튼 위에 추가되어 덮어진 형태라면, set, View는 기존설정을 변경하는 형태
        //즉, 여러 개를 놓기 위해서는 View 들을 여러 개 담을 수 있는 View 그룹이 필요함!(ViewGroup 객체)
        //ViewGroup 객체에 모든 View를 붙인 후, ViewGroup 객체 1개(모든 View가 붙은)를 액티비티에 설정할 것!

        //ViewGroup의 종류(클래스들) 중에 가장 간단한 ~~~~~~~~~~~???
            //LinearLayout이라는 이름의 클래스를 객체로 만들어 사용
            layout= new LinearLayout(this);
            layout.addView(tv);
            layout.addView(btn);    //수평, 수직 설정 가능하며, 디폴트는 수평으로 나열

            //액티비티에 ViewGroup 붙이기
            setContentView(layout);

            //버튼 클릭 시 반응하여 TextView 글씨 변경하기
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tv.setText("Nice to meet you.");
                }
            });

    }
}